package at.sf.socketc.main;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws IOException {
        // need host and port, we want to connect to the ServerSocket at port 7777
        Socket socket = new Socket("localhost", 7777);
        System.out.println("Gib deinen Namen ein:");
		Scanner sc1= new Scanner(System.in);
		String str1 = sc1.nextLine();
		System.out.println("");
        System.out.println("Connected!");
        OutputStream outputStream = socket.getOutputStream();
        DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
    	InputStream inputStream = socket.getInputStream();
        for(int y = 0; y < 100; y--) {
            // get the output stream from the socket.
            // create a data output stream from the output stream so we can send data through it
            

    		Scanner sc= new Scanner(System.in);
        	System.out.print("You: ");
    		String str = sc.nextLine();
            dataOutputStream.writeUTF(str1 + ": " + str);
            dataOutputStream.flush(); // send the message
            DataInputStream dataInputStream = new DataInputStream(inputStream);

            // read the message from the socket
            String message = dataInputStream.readUTF();
            System.out.println(message);
            
        }
            dataOutputStream.close(); // close the output stream when we're done.

        System.out.println("Closing socket and terminating program.");
        socket.close();
    }
}
