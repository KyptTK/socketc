package at.sf.socketc.main;

import java.io.*;
import java.net.*;
import java.util.*;
import static java.nio.charset.StandardCharsets.*;
public class ChatClient
{
    private static Socket Socket;
    static int numberOfClients = 0;
    public static void main(String args[]) 
    {
              //If I wanted to create multiple clients, would this code go here? OR should the new thread creation be outside the while(true) loop?
              while (true)
              {
                  String host = "localhost";
                  int numberOfClients = 0;
                  Thread ChatClient1 = new Thread ()
                  {
                      public void run()
                      {   
                          try
                          {
                              //Client begins, gets port number, listens, connects, prints out messages from other clients
                              int port = 247;
                              int port_1number1 = 247;
                              int numberofmessages = 0;
                              String[] messagessentbyotherclients = null;
                              System.out.println("Try block begins..");
                              System.out.println("Chat client is running");
                              String port_number1= args[0];
                              System.out.println("Port number is: " + port_number1);
                              if(args.length>0)
                              {
                                  port = Integer.valueOf(port_number1);
                              }
                              System.out.println("Listening for connections..");
                              System.out.println( "Listening on port: " + port_number1 );
                              try 
                              {
                                  Socket.connect(null);
                              }
                              catch (IOException e1) 
                              {

                                e1.printStackTrace();
                              }
                              System.out.println("Client has connected to the server");
                              boolean KeepRunning = true;
                              while(KeepRunning)
                              {
                                  for(int i = 0; i < numberOfClients; i++)
                                  {
                                      System.out.println(messagessentbyotherclients);
                                  }
                                  try 
                                  {
                                    //client creates new message from standard input
                                    OutputStream os = Socket.getOutputStream();
                                    OutputStreamWriter osw = new OutputStreamWriter(os);
                                    BufferedWriter bw = new BufferedWriter(osw);
                                  }
                                  catch (IOException e)
                                  {
                                    e.printStackTrace();
                                  }
                                  //creating message to send from standard input
                                  String newmessage = "";
                                  try   
                                  {
                                      // input the message from standard input encoded in UTF-8 string format
                                      BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
                                      String line = "";
                                      System.out.println( "Standard input (press enter then control D when finished): " );
                                      while( (line= input.readLine()) != null )     
                                      {
                                          newmessage += line + " ";
                                          input=null;
                                      }
                                  }
                                  catch ( Exception e )
                                  {
                                      System.out.println( e.getMessage() );
                                  }
                                  //Sending the message to server
                                  String sendMessage = newmessage;
                                  try 
                                  {
                                    OutputStream os = Socket.getOutputStream();
                                    OutputStreamWriter osw = new OutputStreamWriter(os);
                                    BufferedWriter bw = new BufferedWriter(osw);
                                    bw.write(sendMessage + "\n");
                                    bw.flush();
                                  } 
                                  catch (IOException e)
                                  {
                                    e.printStackTrace();
                                  }
                                  System.out.println("Message sent to server: "+sendMessage);
                              }

                          }
                          finally
                          {

                          }

                      }
                  };
                  ChatClient1.start();    
              }
    }
}